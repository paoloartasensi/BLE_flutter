package com.mycompany.bleiot

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
