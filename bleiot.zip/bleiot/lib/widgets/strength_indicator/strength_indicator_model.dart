import '/flutter_flow/flutter_flow_util.dart';
import 'strength_indicator_widget.dart' show StrengthIndicatorWidget;
import 'package:flutter/material.dart';

class StrengthIndicatorModel extends FlutterFlowModel<StrengthIndicatorWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
